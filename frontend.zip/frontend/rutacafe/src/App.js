
import React from 'react';
/* Importamos un boton del componente semantico*/
import { Navegation } from './routes';

function App() {
  return (
    <div className="App">
      
        <Navegation>

        </Navegation>
          
    </div>
  );
}

export default App;
