import {ClienteLayout } from '../layouts'
import { Home, Emprendimientos} from '../pages/Cliente'

const routesCliete = [
    {
        path: "/",
        layout: ClienteLayout,
        component: Home,
    },
    {
        path: "/emprendimientos",
        layout: ClienteLayout,
        component: Emprendimientos,
    },
];

export default routesCliete