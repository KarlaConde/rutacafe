import {adminlayout } from '../layouts';
import { HomeAdmin } from '../pages/Admin/';

const routesAdmin = [

    {
        path: "/admin",
        layout: adminlayout,
        component: HomeAdmin,
        exac: true
    },
];

export default routesAdmin; 