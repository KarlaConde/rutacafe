import React from 'react'
import { Menu, Input } from 'semantic-ui-react'
import './Footer.scss'

export function Footer() {
  return (
    <div>
    <Menu> 
        <Menu.Item disabled> 
        (c) Desarrollo Realizado por la asi. Interfaces y multimedia
        </Menu.Item>
        <Menu.Item position='right'>
            <Input disabled label='Autor> Karla Conde'></Input>
        </Menu.Item>
        <Menu.Item>
            <Input disabled label='Año 2023'></Input>
        </Menu.Item>

    </Menu>
        { /*Modelo css*/}

    <footer className='container'>
        <h1 className='container__letra'>Footer UIDE</h1>
        <p className='container__parrafo'>
            (c) Proyecto Desarrollado en IM <br/>
            <a href='/'>Politicas</a>
            
        </p>
    </footer>
    </div>
  )

}
