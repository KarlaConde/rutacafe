import React from 'react'
import { useEffect, useState } from 'react';
//import { Card, Icon, Image } from 'semantic-ui-css';

export function Emprendedor() {

    const [data, setData]= useState ([])
    const url='http://localhost:8000';

    useEffect (() => {
        fetch ("http://127.0.0.1:8000/administracion/api/emprendedores")
        .then ((response) => response.json())
        //.then((data) => console.log(data));
        .then((data) => setData(data));
    })
  return (
    <div>

      {data.map ((item) => (
        <div key ={item.id}>
          <h2>{item.first_name}</h2>
        </div> 
        
      )
      )}

    </div>
  )
}