import React from 'react'
import { useEffect, useState } from 'react';


export function Producto() {

    const [data, setData]= useState ([])
    const url='http://localhost:8000';

    useEffect (() => {
        fetch ("http://127.0.0.1:8000")
        .then ((response) => response.json())
        //.then((data) => console.log(data));
        .then((data) => setData(data));
    })
  return (
    <div>

      {data.map ((item) => (
        <div key ={item.id}>
          <h2>{item.nombre_prod}</h2>
        </div> 
        
      )
      )}

    </div>
  )
}