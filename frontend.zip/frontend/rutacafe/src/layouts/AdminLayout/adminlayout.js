import React from 'react';
import './adminlayout.scss'
import { LoginAdmin } from '../../pages/Admin/';

export function adminlayout (props){

    const { children } = props
    const auth = null; 

    /* agregamos la condicion de verificacion 
    en el return de if agregamos la opcion del login admin 
    e importamos dedsde el pages admin */ 

    if (!auth) return <LoginAdmin/>

    return(
        <div>
            <p>Pantalla de administrador</p>
            {children}
        </div>
    )
}