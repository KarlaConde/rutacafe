import React from 'react'

export function BasicLayout( props ) {
  const {children} = props;
  return children; 

}
