import React from 'react';
import './LoginAdmin.scss';
import { LoginForm } from '../../../componentes/Admin/LoginForm';


export function LoginAdmin() {
  return (
    
    <div className='login-admin'>
      <div className='login-admin__content'>
        <h1>Entrar al formulario
        <LoginForm/>
        </h1>
      </div>
    </div>
  )
}
