import React from 'react'

export function HomeAdmin() {
  return (
    <div>
        <h1>Pagina de inicio del administrador</h1>
    </div>
  )
}
