import React from 'react'

export function Emprendimientos() {
  return (
    <div>
        <p>Listado de todos los emprendimientos</p>
    </div>
  )
}
