import React from 'react'
import {  Footer, Header, Emprendimiento, Producto, Emprendedor } from  '../../componentes/Cliente'

export function Home() {
  return (
    <div> 
        <Header/>
        <Emprendimiento/>
        <Emprendedor/>
        <Producto/>
        <Footer/>

    </div>
  )
}
