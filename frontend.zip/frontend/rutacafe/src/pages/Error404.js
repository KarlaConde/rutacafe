import React from 'react'

export function Error404() {
  return (
    <div>
        <p>Error 404</p>
    </div>
  )
}
